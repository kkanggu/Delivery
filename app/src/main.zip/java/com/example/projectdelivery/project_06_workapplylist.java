package com.example.projectdelivery;

import androidx.fragment.app.Fragment;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.Spinner;
import android.widget.TextView;

import java.util.ArrayList;

public class project_06_workapplylist extends Fragment
{
	View m_view;
	Spinner m_applylist_Spinner;
	boolean m_bExpensive;
	ListView m_listView;
	ArrayList < worklist_Item > m_works;
	
	
	public class workAdapter extends BaseAdapter
	{
		Context m_Context = null;
		LayoutInflater m_layoutInflater = null;
		ArrayList < worklist_Item > m_item;
		
		public workAdapter ( Context context , ArrayList < worklist_Item > item )
		{
			m_Context = context;
			m_item = item;
			m_layoutInflater = LayoutInflater.from ( context );
		}
		
		@Override
		public int getCount ()
		{
			return m_item.size ();
		}
		
		@Override
		public Object getItem ( int position )
		{
			return m_item.get ( position );
		}
		
		@Override
		public long getItemId ( int position )
		{
			return position;
		}
		
		@Override
		public View getView ( int position , View convertView , ViewGroup parent )
		{
			View view = m_layoutInflater.inflate ( R.layout.worklist_listview , null );
			ImageView image = ( ImageView ) view.findViewById ( R.id.work_Image );
			TextView subject = ( TextView ) view.findViewById ( R.id.work_Subject );
			TextView distance = ( TextView ) view.findViewById ( R.id.work_Distance );
			TextView value = ( TextView ) view.findViewById ( R.id.work_Value );
			
			image.setImageResource ( R.mipmap.icon_custom_female );
			subject.setText ( m_item.get ( position ).m_strSubject );
			distance.setText ( m_item.get ( position ).m_strContent );
			value.setText ( Integer.toString ( m_item.get ( position ).m_iValue ) + "원" );
			
			return view;
		}
	}
	
	public void initializeArrayList ()
	{
		m_works = new ArrayList < worklist_Item > ();
		
		m_works.add ( new worklist_Item ( "시험1" , 5000 ) );
		m_works.add ( new worklist_Item ( "시험5" , 1000 ) );
		m_works.add ( new worklist_Item ( "시험1" , 5000 ) );
		m_works.add ( new worklist_Item ( "시험5" , 1000 ) );
		m_works.add ( new worklist_Item ( "시험1" , 5000 ) );
		m_works.add ( new worklist_Item ( "시험5" , 1000 ) );
	}
	
	public void sortArrayList ()
	{
		// bExpensive에 따라서 ArrayList를 정렬해주는 함수
		// true 이면 가격이 높은거 정렬, false면 거리순 정렬
	}
	
	public void addWork ()
	{
		// 일 신청 버튼을 누르고, 그 일을 추가하여 현재 옵션에 맞게 정렬해주는 함수
	}
	
	@Override
	public void onCreate ( Bundle savedInstanceState )
	{
		super.onCreate ( savedInstanceState );
	}
	
	@Override
	public View onCreateView ( LayoutInflater inflater , ViewGroup container , Bundle savedInstanceState )
	
	{
		m_view = inflater.inflate ( R.layout.project_06_workapplylist , container , false );
		m_applylist_Spinner = ( Spinner ) m_view.findViewById ( R.id.workapplylist_Spinner );
		
		m_applylist_Spinner.setOnItemSelectedListener ( new AdapterView.OnItemSelectedListener ()
		{
			@Override
			public void onItemSelected ( AdapterView < ? > parent , View view , int position , long id )
			{
				if ( 0 == position )
					m_bExpensive = true;
				else
					m_bExpensive = false;
				
				sortArrayList ();
			}
			
			@Override
			public void onNothingSelected ( AdapterView < ? > parent )
			{
				m_bExpensive = true;
			}
		} );
		
		initializeArrayList ();
		
		m_listView = ( ListView ) m_view.findViewById ( R.id.workapplylist_ListView );
		m_listView.setAdapter ( new project_06_workapplylist.workAdapter ( this.getContext () , m_works ) );
		
		m_listView.setOnItemClickListener ( new AdapterView.OnItemClickListener ()
		{
			@Override
			public void onItemClick ( AdapterView < ? > parent , View view , int position , long id )
			{
				Intent intent = new Intent ( getContext () , project_07_workinfo.class );
				intent.putExtra ( "workID" , - 1 );                    // 클릭한 일을 특정할 수 있는 정보를 추가
				intent.putExtra ( "Applied" , true );                // 매칭이 이루어진 일
				
				
				startActivityForResult ( intent , 2 );
			}
		} );
		
		
		return m_view;
	}
}