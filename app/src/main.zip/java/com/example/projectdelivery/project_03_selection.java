package com.example.projectdelivery;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class project_03_selection extends AppCompatActivity implements View.OnClickListener
{
	Button m_btn_selection_Work;
	Button m_btn_selection_Employ;
	
	
	@Override
	protected void onCreate ( Bundle savedInstanceState )
	{
		super.onCreate ( savedInstanceState );
		setContentView ( R.layout.project_03_selection );
		
		m_btn_selection_Work = ( Button ) findViewById ( R.id.selection_Work );
		m_btn_selection_Employ = ( Button ) findViewById ( R.id.selection_Employ );
		
		m_btn_selection_Work.setOnClickListener ( this );
		m_btn_selection_Employ.setOnClickListener ( this );
	}
	
	@Override
	public void onClick ( View view )
	{
		if ( view == m_btn_selection_Work )
		{
			Intent intent = new Intent ( getApplicationContext () , project_04_tab_main.class );
			startActivity ( intent );
		}
		else if ( view == m_btn_selection_Employ )
		{
			Intent intent = new Intent ( getApplicationContext () , project_09_registerlist.class );
			startActivity ( intent );
		}
	}
}