package com.example.projectdelivery;

import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentStatePagerAdapter;

public class ContentPagerAdapter extends FragmentStatePagerAdapter
{
	int m_iPageCnt;
	
	
	public ContentPagerAdapter ( FragmentManager fragmentManager , int iPageCnt )
	{
		super ( fragmentManager );
		m_iPageCnt = iPageCnt;
	}
	
	@Override
	public Fragment getItem ( int position )
	{
		if ( 0 == position )
		{
			project_05_work_list fragment1 = new project_05_work_list ();
			
			return fragment1;
		}
		else if ( 1 == position )
		{
			project_06_workapplylist fragment2 = new project_06_workapplylist ();
			
			return fragment2;
		}
		
		return null;
	}
	
	@Override
	public int getCount ()
	{
		return m_iPageCnt;
	}
}
