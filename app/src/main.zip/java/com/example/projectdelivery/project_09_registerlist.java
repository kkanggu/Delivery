package com.example.projectdelivery;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;

import java.util.ArrayList;

public class project_09_registerlist extends AppCompatActivity implements View.OnClickListener
{
	ListView m_listView;
	Button m_btn_Register;
	ArrayList < worklist_Item > m_works;
	int m_iApplyCode;
	
	public class workAdapter extends BaseAdapter
	{
		Context m_Context = null;
		LayoutInflater m_layoutInflater = null;
		ArrayList < worklist_Item > m_item;
		
		public workAdapter ( Context context , ArrayList < worklist_Item > item )
		{
			m_Context = context;
			m_item = item;
			m_layoutInflater = LayoutInflater.from ( context );
		}
		
		@Override
		public int getCount ()
		{
			return m_item.size ();
		}
		
		@Override
		public Object getItem ( int position )
		{
			return m_item.get ( position );
		}
		
		@Override
		public long getItemId ( int position )
		{
			return position;
		}
		
		@Override
		public View getView ( int position , View convertView , ViewGroup parent )
		{
			View view = m_layoutInflater.inflate ( R.layout.worklist_listview , null );
			ImageView imageCategory = ( ImageView ) view.findViewById ( R.id.work_Image );
			TextView subject = ( TextView ) view.findViewById ( R.id.work_Subject );
			TextView value = ( TextView ) view.findViewById ( R.id.work_Value );
			ImageView imageState = ( ImageView ) view.findViewById ( R.id.work_Register_Image );
			
			//imageCategory.setImageResource ( R.drawable.tab_icon2 );                                // 이거 처리
			//R.drawable.ic_baseline_moped_24														// 배달 아이콘
			//R.drawable.ic_baseline_fastfood_24													// 음식 아이콘
			//R.drawable.ic_baseline_home_24														// 집안일 아이콘
			//R.drawable.ic_baseline_help_outline_24												// 기타 아이콘
			value.setText ( Integer.toString ( m_item.get ( position ).m_iValue ) + "원" );
			subject.setText ( m_item.get ( position ).m_strSubject );
			imageState.setVisibility ( View.VISIBLE );
			//imageState.setImageResource ( R.drawable.tab_icon3 );                                 // 일 상태 표시
			//R.drawable.ic_baseline_done_24														// 이거는 완료되었다는 표시
			//R.drawable.ic_baseline_more_horiz_24													// 아직 진행중인 일 표시
			
			return view;
		}
	}
	
	public void initializeWork ()
	{
		m_works = new ArrayList < worklist_Item > ();
		
		m_works.add ( new worklist_Item ( "시험1" , 5000 ) );
		m_works.add ( new worklist_Item ( "시험2" , 6000 ) );
		m_works.add ( new worklist_Item ( "시험3" , 7000 ) );
	}
	
	@Override
	protected void onCreate ( Bundle savedInstanceState )
	{
		super.onCreate ( savedInstanceState );
		setContentView ( R.layout.project_09_registerlist );
		
		m_btn_Register = ( Button ) findViewById ( R.id.registerlist_Button_Register );
		
		m_btn_Register.setOnClickListener ( this );
		
		initializeWork ();
		
		m_listView = ( ListView ) findViewById ( R.id.registerlist_ListView );
		m_listView.setAdapter ( new workAdapter ( this.getApplicationContext () , m_works ) );
		
		m_listView.setOnItemClickListener ( new AdapterView.OnItemClickListener ()
		{
			@Override
			public void onItemClick ( AdapterView < ? > parent , View view , int position , long id )
			{
				Intent intent = new Intent ( getApplicationContext () , project_10_userapplylist.class );
				m_iApplyCode = m_works.get ( position ).m_iWorkID;    // 클릭한 일의 id 가져오기
				intent.putExtra ( "workID" , 20 );               	  // 클릭한 일을 특정할 수 있는 정보를 추가
				startActivityForResult ( intent , 1 );																		// 이거 왜 ForResult 붙인건지 모르겠음
			}
		} );																												// 만약에 쓸모 없으면 startActivity로 하고
	}																														// 밑에 onActivityResult 지워도 됨
	
	@Override
	public void onClick ( View view )
	{
		if ( view == m_btn_Register )
		{
			Intent intent = new Intent ( getApplicationContext () , project_11_registerwork.class );
			startActivity ( intent );
		}
	}
	
	@Override
	protected void onActivityResult ( int requestCode , int resultCode , @Nullable Intent data )
	{
		super.onActivityResult ( requestCode , resultCode , data );
	}
}