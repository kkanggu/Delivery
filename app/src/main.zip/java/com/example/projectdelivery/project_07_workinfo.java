package com.example.projectdelivery;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

public class project_07_workinfo extends AppCompatActivity implements View.OnClickListener
{
	ImageView m_image_work;
	TextView m_text_Name;
	TextView m_text_Distance;
	TextView m_text_Value;
	TextView m_text_Content;
	int m_iWorkNum;
	boolean m_bApplied;
	Button m_btn_Apply;
	Button m_btn_Back;
	Button m_btn_Messenger;
	
	public void renderWork ()
	{
		if ( 0 == 5 )        // 일 ID 이용해서 찾기
			;                // Image 처리
		
		m_text_Name.setText ( "id로 일 찾아서" );                                            // 제목
		m_text_Distance.setText ( "각 일에 해당하는거 가져오고" );                            // 거리
		m_text_Value.setText ( "거리랑 가격은 m km, 10,000 처럼 쉼표랑 원 처리 해야함" );        // 가격
		m_text_Content.setText ( "화띵" );                                                // 일 내용
		
		
		if ( m_bApplied )                                                // Use Messenger
		{
			m_btn_Apply.setVisibility ( View.INVISIBLE );
			m_btn_Apply.setEnabled ( false );
			m_btn_Messenger.setVisibility ( View.VISIBLE );
			m_btn_Messenger.setEnabled ( true );
		}
		
		
	}
	
	@Override
	protected void onCreate ( Bundle savedInstanceState )
	{
		super.onCreate ( savedInstanceState );
		setContentView ( R.layout.project_07_workinfo );
		
		m_image_work = ( ImageView ) findViewById ( R.id.workinfo_Image );
		m_text_Name = ( TextView ) findViewById ( R.id.workinfo_WorkName );
		m_text_Distance = ( TextView ) findViewById ( R.id.workinfo_Distance );
		m_text_Value = ( TextView ) findViewById ( R.id.workinfo_Value );
		m_text_Content = ( TextView ) findViewById ( R.id.workinfo_WorkContent );
		m_iWorkNum = getIntent ().getExtras ().getInt ( "workID" );
		m_bApplied = getIntent ().getExtras ().getBoolean ( "Applied" );
		
		m_btn_Apply = ( Button ) findViewById ( R.id.workinfo_Button_Apply );
		m_btn_Back = ( Button ) findViewById ( R.id.workInfo_Button_Back );
		
		
		m_btn_Back.setOnClickListener ( this );
		
		if ( ! m_bApplied )                    // 아직 매칭이 된 일이 아닐 경우
		{
			m_btn_Apply.setOnClickListener ( this );
		}
		else                                // 매칭이 된 일이다
		{
			m_btn_Messenger = ( Button ) findViewById ( R.id.workinfo_Button_Messenger );
			m_btn_Messenger.setOnClickListener ( this );
			
			m_btn_Apply.setEnabled ( false );
			m_btn_Apply.setVisibility ( View.INVISIBLE );
		}
		
		renderWork ();
	}
	
	@Override
	public void onClick ( View view )
	{
		if ( view == m_btn_Apply )
		{
			// 신청하는 거 정보 전해주기
			
			Intent intent = new Intent ();
			
			intent.putExtra ( "apply" , true );
			setResult ( 1 , intent );
			finish ();
		}
		else if ( view == m_btn_Back )
		{
			finish ();
		}
		else if ( view == m_btn_Messenger )
		{
			Intent intent = new Intent ( getApplicationContext () , project_08_messenger.class );
			intent.putExtra ( "workID" , m_iWorkNum );
			intent.putExtra ( "User" , true );            // true면 내가 일함, false면 내가 사장
			startActivity ( intent );
		}
	}
}