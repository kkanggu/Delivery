package com.example.projectdelivery;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioGroup;

import com.naver.maps.geometry.LatLng;

public class project_11_registerwork extends AppCompatActivity implements View.OnClickListener
{
	Button m_btn_Back;
	Button m_btn_Register;
	RadioGroup m_group_Radio1;
	RadioGroup m_group_Radio2;
	EditText m_edit_Name;
	EditText m_edit_Value;
	EditText m_edit_Content;
	LatLng m_latLng ;
	int m_iValue;
	
	@Override
	protected void onCreate ( Bundle savedInstanceState )
	{
		super.onCreate ( savedInstanceState );
		setContentView ( R.layout.project_11_registerwork );
		
		m_btn_Back = ( Button ) findViewById ( R.id.registerwork_Button_Back );
		m_btn_Register = ( Button ) findViewById ( R.id.registerwork_Button_Register );
		
		m_group_Radio1 = ( RadioGroup ) findViewById ( R.id.registerwork_Group_Radio1 );
		m_group_Radio2 = ( RadioGroup ) findViewById ( R.id.registerwork_Group_Radio2 );
		
		m_edit_Name = ( EditText ) findViewById ( R.id.registerwork_Edit_Name );
		m_edit_Value = ( EditText ) findViewById ( R.id.registerwork_Edit_Value );
		m_edit_Content = ( EditText ) findViewById ( R.id.registerwork_Edit_Content );
		
		m_group_Radio1.clearCheck ();
		m_group_Radio1.setOnCheckedChangeListener ( listener1 );
		m_group_Radio2.clearCheck ();
		m_group_Radio2.setOnCheckedChangeListener ( listener2 );
		
		m_edit_Value.addTextChangedListener ( new TextWatcher ()
		{
			@Override
			public void beforeTextChanged ( CharSequence s , int start , int count , int after )
			{
			
			}
			
			@Override
			public void onTextChanged ( CharSequence s , int start , int before , int count )
			{
			
			}
			
			@Override
			public void afterTextChanged ( Editable s )
			{
				m_iValue = Integer.parseInt ( m_edit_Value.getText ().toString () );			// 그거 처리 귀찮으니까 미리 숫자는 따로 저장하기
				// 숫자 4000이 들어왔다고 칩시다
				// 그거를 4,000원 이라고 표시해야함.
			}
		} );
		
		m_btn_Back.setOnClickListener ( this ) ;
		m_btn_Register.setOnClickListener ( this ) ;
	}
	
	private RadioGroup.OnCheckedChangeListener listener1 = new RadioGroup.OnCheckedChangeListener ()
	{
		@Override
		public void onCheckedChanged ( RadioGroup group , int checkedId )
		{
			if ( - 1 != checkedId )
			{
				m_group_Radio2.setOnCheckedChangeListener ( null );
				m_group_Radio2.clearCheck ();
				m_group_Radio2.setOnCheckedChangeListener ( listener2 );
			}
		}
	};
	
	private RadioGroup.OnCheckedChangeListener listener2 = new RadioGroup.OnCheckedChangeListener ()
	{
		@Override
		public void onCheckedChanged ( RadioGroup group , int checkedId )
		{
			if ( - 1 != checkedId )
			{
				m_group_Radio1.setOnCheckedChangeListener ( null );
				m_group_Radio1.clearCheck ();
				m_group_Radio1.setOnCheckedChangeListener ( listener1 );
			}
		}
	};
	
	@Override
	public void onClick ( View view )
	{
		switch ( view.getId () )
		{
			case R.id.registerwork_Radio_Deliver:
			{
				// DO
				break;
			}
			case R.id.registerwork_Radio_Food:
			{
				// DO
				break;
			}
			case R.id.registerwork_Radio_Home:
			{
				// DO
				break;
			}
			case R.id.registerwork_Radio_ETC:
			{
				// DO
				break;
			}
			case R.id.registerwork_Button_Back :
			{
				finish ();
				break;
			}
			case R.id.registerwork_Button_Register :
			{
				Intent intent = new Intent ( getApplicationContext () , MapFragmentActivity.class );
				startActivityForResult ( intent , 17 );
				break;
			}
		}
	}
	
	@Override
	public void onActivityResult ( int requestCode , int resultCode , @Nullable Intent data )
	{
		if ( 17 == requestCode && RESULT_OK == resultCode )
		{
			m_latLng = data.getParcelableExtra ( "Latlng" ) ;
			
			// 버튼 누르면 위치 확인하고 바로 전달
			// 정보 다 들어왔으니까 그거 서버에 전달
			
			super.onActivityResult ( requestCode , resultCode , data );
			
			finish ();
		}
	}
}