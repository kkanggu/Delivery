package com.example.projectdelivery;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;

import java.util.ArrayList;

public class project_10_userapplylist extends AppCompatActivity implements View.OnClickListener
{
	ListView m_listView;
	TextView m_text_Category;
	TextView m_text_Name;
	TextView m_text_Value;
	TextView m_text_Content;
	Button m_btn_Back;
	Button m_btn_Messenger;
	ArrayList < userlist_item > m_users;
	int m_iWorkID;
	CustomDialog m_customDialog;
	
	public void initializeUser ()                                    // 일 ID로 지원한 유저들 받아서 Arraylist에 저장
	{
		m_users = new ArrayList < userlist_item > ();
		
		m_text_Category.setText ( "집안일" );
		m_text_Name.setText ( "쓰레기 버려주세요" );
		m_text_Value.setText ( "3,000원" );
		m_text_Content.setText ( "다리 다쳤는데 이거 길게 쓰기 귀찮ㄹㅇㅎㅁㅎㅇㄶㅁㅎㅁㅇㄶㅁ" );
		
		
		if ( true )									// 매칭이 되어 있는지 user2_id 값으로 확인
		{
			m_users.add ( new userlist_item ( "ABC" , true ) );
		}
	}
	
	public class userAdapter extends BaseAdapter
	{
		Context m_Context = null;
		LayoutInflater m_layoutInflater = null;
		ArrayList < userlist_item > m_item;
		
		public userAdapter ( Context context , ArrayList < userlist_item > item )
		{
			m_Context = context;
			m_item = item;
			m_layoutInflater = LayoutInflater.from ( context );
		}
		
		@Override
		public int getCount ()
		{
			return m_item.size ();
		}
		
		@Override
		public Object getItem ( int position )
		{
			return m_item.get ( position );
		}
		
		@Override
		public long getItemId ( int position )
		{
			return position;
		}
		
		@Override
		public View getView ( int position , View convertView , ViewGroup parent )
		{
			View view = m_layoutInflater.inflate ( R.layout.userlist_listview , null );
			ImageView imageCategory = ( ImageView ) view.findViewById ( R.id.user_Image );
			TextView name = ( TextView ) view.findViewById ( R.id.user_Name );
			TextView distance = ( TextView ) view.findViewById ( R.id.user_Distance );
			
			//imageCategory.setImageResource ( R.drawable.tab_icon2 );                                // 이거 처리
			name.setText ( m_item.get ( position ).m_strName );
			distance.setText ( m_item.get ( position ).m_strName );                                    // 이거는 gps로 거리 처리하고 설정해야함 지금 대충해놨음
			
			return view;
		}
	}
	
	@Override
	protected void onCreate ( Bundle savedInstanceState )
	{
		super.onCreate ( savedInstanceState );
		setContentView ( R.layout.project_10_userapplylist );
		
		m_btn_Back = ( Button ) findViewById ( R.id.userapplylist_Back );
		m_text_Category = ( TextView ) findViewById ( R.id.userapplylist_Work_Category );
		m_text_Name = ( TextView ) findViewById ( R.id.userapplylist_Work_Name );
		m_text_Value = ( TextView ) findViewById ( R.id.userapplylist_Work_Value );
		m_text_Content = ( TextView ) findViewById ( R.id.userapplylist_Work_Content );
		
		m_btn_Back.setOnClickListener ( this );
		
		m_iWorkID = getIntent ().getExtras ().getInt ( "workID" );
		m_listView = ( ListView ) findViewById ( R.id.userapplylist_Listview );
		
		initializeUser ();
		
		if ( true)																		// 구인이 되었으면
		{
			m_btn_Messenger = ( Button ) findViewById ( R.id.userapplylist_Button_Messenger );
			
			m_btn_Messenger.setEnabled ( true );
			m_btn_Messenger.setVisibility ( View.VISIBLE );
			
			m_btn_Messenger.setOnClickListener ( new View.OnClickListener ()
			{
				@Override
				public void onClick ( View view )
				{
					if ( view == m_btn_Messenger )
					{
						Intent intent = new Intent ( getApplicationContext () , project_08_messenger.class );
						intent.putExtra ( "workID" , m_iWorkID );
						intent.putExtra ( "User" , false );            // true면 내가 일함, false면 내가 사장
						startActivity ( intent );
					}
				}
			} );
			
			m_listView.setAdapter ( new userAdapter ( this.getApplicationContext () , m_users ) );
		}
	}
	
	View.OnClickListener positiveListener = new View.OnClickListener ()
	{
		@Override
		public void onClick ( View view )
		{
			// 예 버튼 누르고 처리
			
			m_customDialog.dismiss ();
			finish ();
		}
	};
	
	View.OnClickListener negativeListener = new View.OnClickListener ()
	{
		@Override
		public void onClick ( View view )
		{
			m_customDialog.dismiss ();
		}
	};
	
	@Override
	public void onClick ( View view )
	{
		if ( view == m_btn_Back )
			finish ();
	}
}