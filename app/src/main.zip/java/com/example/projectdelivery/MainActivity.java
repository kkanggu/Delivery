package com.example.projectdelivery;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import android.Manifest;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.hardware.camera2.CameraManager;
import android.location.LocationManager;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.gun0912.tedpermission.PermissionListener;
import com.gun0912.tedpermission.TedPermission;

import java.util.List;

public class MainActivity extends AppCompatActivity implements View.OnClickListener
{
	Button m_btn_SignIn;
	Button m_btn_SignUp;
	TextView m_view_WrongInput;
	
	@Override
	protected void onCreate ( Bundle savedInstanceState )
	{
		super.onCreate ( savedInstanceState );
		setContentView ( R.layout.project_01_signin );
		
		askPermission ();
		
		m_btn_SignIn = ( Button ) findViewById ( R.id.signIn_Button_SignIn );
		m_btn_SignUp = ( Button ) findViewById ( R.id.signIn_Button_SignUp );
		m_view_WrongInput = ( TextView ) findViewById ( R.id.signIn_WrongInput );
		
		m_btn_SignIn.setOnClickListener ( this );
		m_btn_SignUp.setOnClickListener ( this );
	}
	
	@Override
	public void onClick ( View view )
	{
		if ( view == m_btn_SignIn )
		{
//			do something
			Intent intent = new Intent ( getApplicationContext () , project_03_selection.class );
			startActivity ( intent );
		}
		else if ( view == m_btn_SignUp )
		{
			Intent intent = new Intent ( getApplicationContext () , project_02_signup.class );
			startActivity ( intent );
		}
	}
	
	public void askPermission ()
	{
		PermissionListener permissionListener1 = new PermissionListener ()
		{
			@Override
			public void onPermissionGranted ()
			{
				Toast.makeText ( MainActivity.this , "위치 권한 허가" , Toast.LENGTH_SHORT ).show ();
			}
			
			@Override
			public void onPermissionDenied ( List < String > deniedPermissions )
			{
			
			}
		};
		
		TedPermission.with ( this )
				.setPermissionListener ( permissionListener1 )
				.setRationaleMessage ( "일을 구하거나 등록하기 위해서는 위치 권한이 필요합니다." )
				.setDeniedMessage ( "[설정] -> [권한] 에서 권한을 허용해주시기 바랍니다." )
				.setPermissions ( Manifest.permission.ACCESS_FINE_LOCATION )
				.setPermissions ( Manifest.permission.ACCESS_COARSE_LOCATION )
				.check ();
		
		PermissionListener permissionListener2 = new PermissionListener ()
		{
			@Override
			public void onPermissionGranted ()
			{
				Toast.makeText ( MainActivity.this , "파일 접근 권한 허가" , Toast.LENGTH_SHORT ).show ();
			}
			
			@Override
			public void onPermissionDenied ( List < String > deniedPermissions )
			{
			
			}
		};
		
		TedPermission.with ( this )
				.setPermissionListener ( permissionListener2 )
				.setRationaleMessage ( "일을 구하거나 등록하기 위해서는 위치 권한이 필요합니다." )
				.setDeniedMessage ( "[설정] -> [권한] 에서 권한을 허용해주시기 바랍니다." )
				.setPermissions ( Manifest.permission.READ_EXTERNAL_STORAGE )
				.setPermissions ( Manifest.permission.WRITE_EXTERNAL_STORAGE )
				.check ();
	}
}