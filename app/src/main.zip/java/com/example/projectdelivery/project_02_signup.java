package com.example.projectdelivery;

import android.app.DatePickerDialog;
import android.content.Intent;
import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.RadioButton;
import android.widget.RadioGroup;

public class project_02_signup extends AppCompatActivity implements View.OnClickListener
{
	Button m_btn_SignUp;
	Button m_btn_Age;
	RadioGroup m_group_Radio;
	RadioButton m_btn_Radio1;
	RadioButton m_btn_Radio2;
	boolean m_bMale;
	
	@Override
	protected void onCreate ( Bundle savedInstanceState )
	{
		super.onCreate ( savedInstanceState );
		setContentView ( R.layout.project_02_signup );
		
		m_btn_SignUp = ( Button ) findViewById ( R.id.signUp_Button_SignUp );
		m_btn_Age = ( Button ) findViewById ( R.id.signUp_Button_Age );
		m_group_Radio = ( RadioGroup ) findViewById ( R.id.singUp_Group_Radio );
		m_btn_Radio1 = ( RadioButton ) findViewById ( R.id.singUp_Button_Radio1 );
		m_btn_Radio2 = ( RadioButton ) findViewById ( R.id.singUp_Button_Radio2 );
		
		m_btn_SignUp.setOnClickListener ( this );
		m_btn_Age.setOnClickListener ( this );
		m_group_Radio.setOnClickListener ( this );
		m_btn_Radio1.setOnClickListener ( this );
		m_btn_Radio2.setOnClickListener ( this );
		
	}
	
	@Override
	public void onClick ( View view )
	{
		if ( view == m_btn_SignUp )
		{
//			Check and do
			// 정보 다 들어왔는지 체크하고 넘겨줘야 합니다.
			// EditText findViewByID 하고 값 가져오고 해야됨 까먹고 안썼음
			// 다 입력 안 됐으면
			
			if ( true )
			{
				Intent intent = new Intent ( getApplicationContext () , MainActivity.class );
				startActivity ( intent );
			}
		}
		else if ( view == m_btn_Age )
		{
			CharSequence csYear = m_btn_Age.getText ();
			String strYear = csYear.toString ();
			int iYear = 2000;
			
			
			if ( ! strYear.equals ( "" ) )                // Integer
			{
				iYear = 2021 - Integer.parseInt ( strYear );
			}
			
			
			DatePickerDialog.OnDateSetListener dateSetListener = new DatePickerDialog.OnDateSetListener ()
			{
				@Override
				public void onDateSet ( DatePicker view , int year , int month , int dayOfMonth )
				{
					Log.d ( "Year Picker Test" , "year = " + year + " , month = " + month + ", day = " + dayOfMonth );
					m_btn_Age.setText ( Integer.toString ( 2021 - year ) );
				}
			};
			yearPickerDialog pickerDialog = new yearPickerDialog ();
			pickerDialog.m_iYear = iYear;
			pickerDialog.setListener ( dateSetListener );
			pickerDialog.show ( getSupportFragmentManager () , "YearpICKDR" );
		}
	}
	
	RadioGroup.OnCheckedChangeListener rgChangedListener = new RadioGroup.OnCheckedChangeListener ()
	{
		@Override
		public void onCheckedChanged ( RadioGroup group , int checkedId )
		{    // 남 녀 성별 체크니까, 요게 체크되면 사용자 정보에 남자 여자 바꾸는 코드 한줄씩 넣으면 됨.
			if ( checkedId == R.id.singUp_Button_Radio1 )
			{
				m_bMale = true;
			}
			else if ( checkedId == R.id.singUp_Button_Radio2 )
			{
				m_bMale = false;
			}
		}
	};
}