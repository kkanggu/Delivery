package com.example.projectdelivery;

import android.Manifest;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.os.Bundle;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

import android.provider.MediaStore;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.gun0912.tedpermission.PermissionListener;
import com.gun0912.tedpermission.TedPermission;

import java.util.ArrayList;
import java.util.List;

import kr.co.bootpay.Bootpay;
import kr.co.bootpay.BootpayAnalytics;
import kr.co.bootpay.enums.Method;
import kr.co.bootpay.enums.PG;
import kr.co.bootpay.enums.UX;
import kr.co.bootpay.listener.CancelListener;
import kr.co.bootpay.listener.CloseListener;
import kr.co.bootpay.listener.ConfirmListener;
import kr.co.bootpay.listener.DoneListener;
import kr.co.bootpay.listener.ErrorListener;
import kr.co.bootpay.listener.ReadyListener;
import kr.co.bootpay.model.BootExtra;
import kr.co.bootpay.model.BootUser;

public class project_08_messenger extends AppCompatActivity implements View.OnClickListener
{
	Button m_btn_Back;
	ImageView m_image_Category;
	TextView m_text_Subject;
	ListView m_listView;
	EditText m_editText;
	Button m_btn_Send;
	Button m_btn_Camera;
	Button m_btn_Pay;
	ArrayList < message_item > m_items;
	CustomDialog m_customDialog;
	UserBootPay m_bootPay;
	int m_iWorkNum;                        // 일의 id로 조회 용도
	boolean m_bWorker;                    // true면 내가 일한다는거
	
	public class messageAdapter extends BaseAdapter
	{
		Context m_Context = null;
		LayoutInflater m_layoutInflater = null;
		ArrayList < message_item > m_item;
		
		public messageAdapter ( Context context , ArrayList < message_item > item )
		{
			m_Context = context;
			m_item = item;
			m_layoutInflater = LayoutInflater.from ( context );
		}
		
		@Override
		public int getCount ()
		{
			return m_item.size ();
		}
		
		@Override
		public Object getItem ( int position )
		{
			return m_item.get ( position );
		}
		
		@Override
		public long getItemId ( int position )
		{
			return position;
		}
		
		@Override
		public View getView ( int position , View convertView , ViewGroup parent )
		{
			View view = m_layoutInflater.inflate ( R.layout.message_listview , null );
			TextView messageText = ( TextView ) view.findViewById ( R.id.message_Text );
			ImageView imageUser = ( ImageView ) view.findViewById ( R.id.message_Image_User );
			ImageView imagePhoto = ( ImageView ) view.findViewById ( R.id.message_Image_Photo );
			RelativeLayout.LayoutParams imgLayoutParams = new RelativeLayout.LayoutParams ( ViewGroup.LayoutParams.WRAP_CONTENT , ViewGroup.LayoutParams.WRAP_CONTENT );
			RelativeLayout.LayoutParams textLayoutParams = new RelativeLayout.LayoutParams ( ViewGroup.LayoutParams.WRAP_CONTENT , ViewGroup.LayoutParams.WRAP_CONTENT );
			boolean bPhoto = false;
			
			if ( m_item.get ( position ).m_strMessage == null )
				bPhoto = true;
			
			
			messageText.setText ( m_item.get ( position ).m_strMessage );
			if ( m_item.get ( position ).m_bWorker )                                                // 내가 보낸거면
			{
				//imageUser.setImageResource ( R.drawable.tab_icon2 );                                    // 이거 일 종류에 맞춰서 이미지 설정하는거 하나 집어넣어야 함
				imgLayoutParams.addRule ( RelativeLayout.ALIGN_PARENT_RIGHT );                        // 이미지 최우측에 붙이기
				imageUser.setLayoutParams ( imgLayoutParams );
				
				textLayoutParams.addRule ( RelativeLayout.LEFT_OF , imageUser.getId () );                // SOMETHING |LEFTOF| IMAGE
				
				
				if ( bPhoto )                                                                        // 사진 처리
				{
					imagePhoto.setLayoutParams ( textLayoutParams );
					imagePhoto.setImageBitmap ( m_item.get ( position ).m_Bitmap );
				}
				else
				{
					messageText.setLayoutParams ( textLayoutParams );
					messageText.setText ( m_item.get ( position ).m_strMessage );
				}
			}
			else
			{
				//image.setImageResource ( R.drawable.tab_icon3 );                                    // 이거 일 종류에 맞춰서 이미지 설정하는거 하나 집어넣어야 함
				textLayoutParams.addRule ( RelativeLayout.RIGHT_OF , imageUser.getId () );            // IMAGE |RIGHTOF| SOMETHING
				
				
				if ( bPhoto )                                                                        // 사진 처리
				{
					imagePhoto.setLayoutParams ( textLayoutParams );
					imagePhoto.setImageBitmap ( m_item.get ( position ).m_Bitmap );
				}
				else
				{
					messageText.setLayoutParams ( textLayoutParams );
					messageText.setText ( m_item.get ( position ).m_strMessage );
				}
			}
			
			return view;
		}
	}
	
	public void initializeMessgae ()
	{
		m_items = new ArrayList < message_item > ();
		
		m_items.add ( new message_item ( "테스트용 메세지 추가합니다" , m_bWorker ) );
		m_items.add ( new message_item ( "이제 사장 말하는거" , ! m_bWorker ) );
		m_items.add ( new message_item ( "돈이나 주세요 제발" , m_bWorker ) );
		m_items.add ( new message_item ( "지금 안하면 시험 조진다 제발 하자" , ! m_bWorker ) );
	}
	
	@Override
	protected void onCreate ( Bundle savedInstanceState )
	{
		super.onCreate ( savedInstanceState );
		setContentView ( R.layout.project_08_messenger );
		
		m_iWorkNum = getIntent ().getExtras ().getInt ( "workID" );
		m_bWorker = getIntent ().getExtras ().getBoolean ( "User" );
		
		m_btn_Back = ( Button ) findViewById ( R.id.messenger_Button_Back );
		m_image_Category = ( ImageView ) findViewById ( R.id.messenger_Image_Category );
		m_text_Subject = ( TextView ) findViewById ( R.id.messenger_Subject );
		m_editText = ( EditText ) findViewById ( R.id.messenger_EditText );
		m_btn_Send = ( Button ) findViewById ( R.id.messenger_Button_Send );
		m_btn_Camera = ( Button ) findViewById ( R.id.messenger_Button_Camera );
		
		m_bootPay = new UserBootPay ();
		m_bootPay.initialize ();
		
		m_btn_Back.setOnClickListener ( this );
		m_btn_Send.setOnClickListener ( this );
		m_btn_Camera.setOnClickListener ( this );
		
		initializeMessgae ();
		
		m_listView = ( ListView ) findViewById ( R.id.messenger_ListView );
		
		
		if ( ! m_bWorker )
		{
			m_btn_Pay = ( Button ) findViewById ( R.id.messenger_Button_Pay );
			m_btn_Pay.setVisibility ( View.VISIBLE );
			m_btn_Pay.setEnabled ( true );
			m_listView.setPadding ( 0 , 0 , 0 , 130 );
			m_btn_Pay.setOnClickListener ( this );
		}
		
		
		m_listView.setAdapter ( new messageAdapter ( this.getApplicationContext () , m_items ) );
	}
	
	@Override
	public void onClick ( View view )
	{
		if ( view == m_btn_Back )
		{
			finish ();
		}
		else if ( view == m_btn_Send )
		{
			// editText.getText() 이용해서 메세지 받아오고, 내가 보냈다는 정보와 메세지를 전송
			// 전송이 되면 다시 그려야하는데 씨발
			m_items.add ( new message_item ( "이거 추가해봄" , true ) );
			onResume ();
		}
		else if ( view == m_btn_Camera )
		{
			if ( ContextCompat.checkSelfPermission ( this , Manifest.permission.CAMERA ) == PackageManager.PERMISSION_GRANTED )                // 카메라 권한이 있으면
			{
				Intent intent = new Intent ( MediaStore.ACTION_IMAGE_CAPTURE );
				if ( intent.resolveActivity ( getPackageManager () ) != null )
					startActivityForResult ( intent , 23 );
			}
			else
			{
				PermissionListener permissionListener2 = new PermissionListener ()
				{
					@Override
					public void onPermissionGranted ()
					{
						Toast.makeText ( project_08_messenger.this , "카메라 권한 허가" , Toast.LENGTH_SHORT ).show ();
					}
					
					@Override
					public void onPermissionDenied ( List < String > deniedPermissions )
					{
					
					}
				};
				TedPermission.with ( this )
						.setPermissionListener ( permissionListener2 )
						.setRationaleMessage ( "결제를 위해서는 카메라 권한이 필요합니다." )
						.setDeniedMessage ( "[설정] -> [권한] 에서 권한을 허용해주시기 바랍니다." )
						.setPermissions ( Manifest.permission.CAMERA )
						.check ();
			}
			
		}
		else if ( view == m_btn_Pay )
		{
			String strValue = "3,000원";                                    // 여기에 Value 값 3,000원 처럼 집어넣어야 함
			boolean bMale = true;                                            // 일 하는 사람의 성별 받아오기
			
			
			m_customDialog = new CustomDialog ( project_08_messenger.this , positiveListener , negativeListener , strValue , "" , "위 유저를 구인하시겠습니까?" , bMale );
			
			m_customDialog.show ();
		}
	}
	
	@Override
	protected void onActivityResult ( int requestCode , int resultCode , @Nullable Intent data )
	{
		super.onActivityResult ( requestCode , resultCode , data );
		
		if ( 23 == requestCode && resultCode == RESULT_OK )
		{
			Bundle extras = data.getExtras ();
			Bitmap bitmap = ( Bitmap ) extras.get ( "data" );
			
			m_items.add ( new message_item ( bitmap , ! m_bWorker ) );
		}
	}
	
	View.OnClickListener positiveListener = new View.OnClickListener ()
	{
		@Override
		public void onClick ( View view )
		{
			// 예 버튼 누르고 결제 처리
			m_bootPay.onClick_request ( view );
			
			m_customDialog.dismiss ();
			
		}
	};
	
	View.OnClickListener negativeListener = new View.OnClickListener ()
	{
		@Override
		public void onClick ( View view )
		{
			m_customDialog.dismiss ();
		}
	};
	
	public class UserBootPay
	{
		private int m_stuck = 10;
		
		public void initialize ()
		{
			BootpayAnalytics.init ( getApplicationContext () , "5fc78ae82fa5c2001d037b9e" );
		}
		
		public void onClick_request ( View view )
		{
			BootUser bootUser = new BootUser ().setPhone ( "010-1234-5678" );
			BootExtra bootExtra = new BootExtra ().setQuotas ( new int[] { 0 , 2 , 3 } );
			//        결제호출
			
			Bootpay.init ( getFragmentManager () ).setApplicationId ( "5fc78ae82fa5c2001d037b9e" ) // 해당 프로젝트(안드로이드)의 application id 값
					.setPG ( PG.KCP ) // 결제할 PG 사
					.setMethod ( Method.KAKAO ) // 결제수단
					.setContext ( getApplicationContext () ).setBootUser ( bootUser ).setBootExtra ( bootExtra ).setUX ( UX.PG_DIALOG )
//                .setUserPhone("010-1234-5678") // 구매자 전화번호
					.setName ( "심부름" ) // 결제할 상품명
					.setOrderId ( "1234" ) // 결제 고유번호expire_month
					.setPrice ( 10000 ) // 결제할 금액
					.addItem ( "심부름 이용료" , 1 , "ITEM_CODE_DELIVER" , 100 ) // 주문정보에 담길 상품정보, 통계를 위해 사용
					.onConfirm ( new ConfirmListener ()
					{ // 결제가 진행되기 바로 직전 호출되는 함수로, 주로 재고처리 등의 로직이 수행
						@Override
						public void onConfirm ( @Nullable String message )
						{
							
							if ( 0 < m_stuck )
								Bootpay.confirm ( message ); // 재고가 있을 경우.
							else
								Bootpay.removePaymentWindow (); // 재고가 없어 중간에 결제창을 닫고 싶을 경우
							Log.d ( "BOOTPAY confirm" , message );
						}
					} ).onDone ( new DoneListener ()
			{ // 결제완료시 호출, 아이템 지급 등 데이터 동기화 로직을 수행합니다
				@Override
				public void onDone ( @Nullable String message )
				{
					Log.d ( "BOOTPAY done" , message );
				}
			} ).onReady ( new ReadyListener ()
			{ // 가상계좌 입금 계좌번호가 발급되면 호출되는 함수입니다.
				@Override
				public void onReady ( @Nullable String message )
				{
					Log.d ( "BOOTPAY ready" , message );
				}
			} ).onCancel ( new CancelListener ()
			{ // 결제 취소시 호출
				@Override
				public void onCancel ( @Nullable String message )
				{
					Log.d ( "BOOTPAY cancel" , message );
					finish ();
				}
			} ).onError ( new ErrorListener ()
			{ // 에러가 났을때 호출되는 부분
				@Override
				public void onError ( @Nullable String message )
				{
					Log.d ( "BOOTPAY error" , message );
				}
			} ).onClose ( new CloseListener ()
			{ //결제창이 닫힐때 실행되는 부분
				@Override
				public void onClose ( String message )
				{
					Log.d ( "BOOTPAY close" , "close" );
				}
			} ).request ();
		}
	}
}