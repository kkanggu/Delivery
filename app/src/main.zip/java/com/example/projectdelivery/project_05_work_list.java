package com.example.projectdelivery;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.location.Address;
import android.location.Geocoder;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.Spinner;
import android.widget.TextView;

import com.naver.maps.geometry.LatLng;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public class project_05_work_list extends Fragment implements View.OnClickListener
{
	View m_view;
	Spinner m_work_Spinner;
	TextView m_LocationText;
	boolean m_bExpensive = true;
	int m_iCnt = 5;                                    // iCnt 말고 전체 일 개수가 따로 파이어베이스에 있으면 그거로 쓰셈
	ArrayList < worklist_Item > m_works;
	ListView m_listView;
	int m_iApplyCode = - 1;
	LatLng m_latLng;
	
	public class workAdapter extends BaseAdapter
	{
		Context m_Context = null;
		LayoutInflater m_layoutInflater = null;
		ArrayList < worklist_Item > m_item;
		
		public workAdapter ( Context context , ArrayList < worklist_Item > item )
		{
			m_Context = context;
			m_item = item;
			m_layoutInflater = LayoutInflater.from ( context );
		}
		
		@Override
		public int getCount ()
		{
			return m_item.size ();
		}
		
		@Override
		public Object getItem ( int position )
		{
			return m_item.get ( position );
		}
		
		@Override
		public long getItemId ( int position )
		{
			return position;
		}
		
		@Override
		public View getView ( int position , View convertView , ViewGroup parent )
		{
			View view = m_layoutInflater.inflate ( R.layout.worklist_listview , null );
			ImageView image = ( ImageView ) view.findViewById ( R.id.work_Image );
			TextView subject = ( TextView ) view.findViewById ( R.id.work_Subject );
			TextView distance = ( TextView ) view.findViewById ( R.id.work_Distance );
			TextView value = ( TextView ) view.findViewById ( R.id.work_Value );
			
			image.setImageResource ( R.mipmap.icon_custom_male );                                        // 성별에 따라 남성 여성 이미지 설정
			//image.setImageResource ( R.mipmap.icon_custom_female);
			subject.setText ( m_item.get ( position ).m_strSubject );
			distance.setText ( m_item.get ( position ).m_strContent );
			value.setText ( Integer.toString ( m_item.get ( position ).m_iValue ) + "원" );
			
			return view;
		}
	}
	
	public void initializeArrayList ()
	{
		m_works = new ArrayList < worklist_Item > ();
		
		m_works.add ( new worklist_Item ( "시험1" , 5000 ) );
	}
	
	
	public void sortArrayList ()
	{
		// bExpensive에 따라서 ArrayList를 정렬해주는 함수
		// true 이면 가격이 높은거 정렬, false면 거리순 정렬
	}
	
	@Override
	public void onCreate ( Bundle savedInstanceState )
	{
		super.onCreate ( savedInstanceState );
	}
	
	@Override
	public View onCreateView ( LayoutInflater inflater , ViewGroup container , Bundle savedInstanceState )
	{
		m_view = inflater.inflate ( R.layout.project_05_work_list , container , false );
		
		m_LocationText = ( TextView ) m_view.findViewById ( R.id.worklist_Location );
		Intent intent = new Intent ( getContext () , MapFragmentActivity.class );
		startActivityForResult ( intent , 17 );
		
		m_LocationText.setOnClickListener ( this );
		
		m_work_Spinner = ( Spinner ) m_view.findViewById ( R.id.worklist_Spinner );
		
		m_work_Spinner.setOnItemSelectedListener ( new AdapterView.OnItemSelectedListener ()
		{
			@Override
			public void onItemSelected ( AdapterView < ? > parent , View view , int position , long id )
			{
				if ( 0 == position )
					m_bExpensive = true;
				else
					m_bExpensive = false;
				
				sortArrayList ();
			}
			
			@Override
			public void onNothingSelected ( AdapterView < ? > parent )
			{
				m_bExpensive = true;
			}
		} );
		
		initializeArrayList ();
		
		m_listView = ( ListView ) m_view.findViewById ( R.id.worklist_ListView );
		m_listView.setAdapter ( new workAdapter ( this.getContext () , m_works ) );
		
		m_listView.setOnItemClickListener ( new AdapterView.OnItemClickListener ()
		{
			@Override
			public void onItemClick ( AdapterView < ? > parent , View view , int position , long id )
			{
				Intent intent = new Intent ( getContext () , project_07_workinfo.class );
				m_iApplyCode = m_works.get ( position ).m_iWorkID;    // 클릭한 일의 id 가져오기
				intent.putExtra ( "workID" , 20 );                // 클릭한 일을 특정할 수 있는 정보를 추가
				intent.putExtra ( "Applied" , false );
				startActivityForResult ( intent , 1 );
			}
		} );
		
		
		return m_view;
	}
	
	@Override
	public void onClick ( View view )
	{
		if ( view == m_LocationText )
		{
			Intent intent = new Intent ( getContext () , MapFragmentActivity.class );
			startActivityForResult ( intent , 17 );
		}
	}
	
	@Override
	public void onActivityResult ( int requestCode , int resultCode , @Nullable Intent data )
	{
		super.onActivityResult ( requestCode , resultCode , data );
		
		
		if ( 1 == requestCode && Activity.RESULT_OK  == resultCode )
		{
			if ( data.getBooleanExtra ( "apply" , false ) == true )
			{
				//	일 신청 버튼 눌렀으니 그에 대한 처리
			}
			
			m_iApplyCode = - 1;
		}
		else if ( 17 == requestCode && Activity.RESULT_OK == resultCode )
		{
			m_latLng = data.getParcelableExtra ( "Latlng" );
			getCurrentAddress ();
		}
	}
	
	public void getCurrentAddress ()
	{
		Geocoder geocoder = new Geocoder ( getActivity () , Locale.getDefault () );
		List < Address > addresses;
		
		try
		{
			addresses = geocoder.getFromLocation ( m_latLng.latitude , m_latLng.longitude , 7 );
			m_LocationText.setText ( addresses.get ( 0 ).getAddressLine ( 0 ).toString () );
		} catch ( IOException e )
		{
			e.printStackTrace ();
		}
		
		
	}
}